package com.example.widecamera

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraCharacteristics
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.CameraInfo
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.media.VolumeProviderCompat
import kotlin.math.atan

@OptIn(ExperimentalCamera2Interop::class)
class CaptureService : LifecycleService() {

    private lateinit var session: MediaSessionCompat
    private var provider: ProcessCameraProvider? = null
    private var busy = false

    override fun onCreate() {
        super.onCreate()

        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("wide", "Wide Camera", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, CaptureService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(this, "wide")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("الكاميرا الوايد جاهزة")
            .setContentText("اضغط رفع الصوت للتصوير")
            .setOngoing(true)
            .addAction(0, "إيقاف", stopIntent)
            .build()
        ServiceCompat.startForeground(
            this, 1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        )

        // MediaSession بتخلي النظام يبعتلنا أزرار الصوت حتى والشاشة مقفولة
        session = MediaSessionCompat(this, "WideCam").apply {
            setPlaybackState(
                PlaybackStateCompat.Builder()
                    .setState(PlaybackStateCompat.STATE_PLAYING, 0, 1f)
                    .build()
            )
            setPlaybackToRemote(object :
                VolumeProviderCompat(VOLUME_CONTROL_RELATIVE, 100, 50) {
                override fun onAdjustVolume(direction: Int) {
                    if (direction > 0) capture()
                }
            })
            isActive = true
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == "STOP") stopSelf()
        return START_STICKY
    }

    override fun onDestroy() {
        session.isActive = false
        session.release()
        provider?.unbindAll()
        super.onDestroy()
    }

    // زاوية الرؤية: كل ما كبرت الكاميرا أوسع
    private fun fov(info: CameraInfo): Double {
        val c2 = Camera2CameraInfo.from(info)
        val focal = c2.getCameraCharacteristic(
            CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS
        )?.minOrNull() ?: return 0.0
        val sensor = c2.getCameraCharacteristic(
            CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE
        ) ?: return 0.0
        return Math.toDegrees(2 * atan(sensor.width / (2.0 * focal)))
    }

    private fun capture() {
        if (busy) return
        busy = true
        buzz(40) // اهتزاز قصير = استلمت الأمر

        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val p = future.get()
                provider = p

                val selector = CameraSelector.Builder()
                    .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                    .addCameraFilter { infos ->
                        val widest = infos.maxByOrNull { fov(it) }
                        if (widest != null) listOf(widest) else infos
                    }
                    .build()

                // من غير Preview عشان نوفر الطاقة، والكاميرا بتتفتح وقت الصورة بس
                val ic = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .setFlashMode(ImageCapture.FLASH_MODE_OFF)
                    .build()

                p.unbindAll()
                p.bindToLifecycle(this, selector, ic)

                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, "WIDE_${System.currentTimeMillis()}")
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/WideCamera")
                }
                val options = ImageCapture.OutputFileOptions.Builder(
                    contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
                ).build()

                ic.takePicture(
                    options,
                    ContextCompat.getMainExecutor(this),
                    object : ImageCapture.OnImageSavedCallback {
                        override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                            p.unbindAll() // نقفل الكاميرا فوراً
                            busy = false
                            buzz(200) // اهتزاز طويل = اتحفظت
                        }

                        override fun onError(e: ImageCaptureException) {
                            p.unbindAll()
                            busy = false
                            buzz(80); buzz(80) // اهتزازتين = فشل
                        }
                    }
                )
            } catch (e: Exception) {
                busy = false
                buzz(80); buzz(80)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun buzz(ms: Long) {
        val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
            getSystemService(VibratorManager::class.java).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    }
}
