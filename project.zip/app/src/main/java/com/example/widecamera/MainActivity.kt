package com.example.widecamera

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        val info = TextView(this).apply {
            text = "فعّل التطبيق، اقفل الشاشة، واضغط رفع الصوت للتصوير بالكاميرا الوايد.\n" +
                "اهتزاز قصير = استلم الأمر\nاهتزاز طويل = الصورة اتحفظت\nاهتزازتين = فشل"
            textSize = 16f
            gravity = Gravity.CENTER
        }
        val start = Button(this).apply {
            text = "تفعيل"
            setOnClickListener { startIfPermitted() }
        }
        val stop = Button(this).apply {
            text = "إيقاف"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                Toast.makeText(this@MainActivity, "اتوقف", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(info)
        root.addView(start)
        root.addView(stop)
        setContentView(root)
    }

    private fun neededPermissions(): Array<String> {
        val list = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) list += Manifest.permission.POST_NOTIFICATIONS
        return list.toTypedArray()
    }

    private fun startIfPermitted() {
        val missing = neededPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 20)
            return
        }
        // لازم يبدأ والتطبيق ظاهر على الشاشة عشان أندرويد يسمح للسيرفس يستخدم الكاميرا
        ContextCompat.startForegroundService(this, Intent(this, CaptureService::class.java))
        Toast.makeText(this, "اشتغل، اقفل الشاشة وجرب رفع الصوت", Toast.LENGTH_LONG).show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 20 && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            startIfPermitted()
        } else {
            Toast.makeText(this, "محتاج الصلاحيات كلها", Toast.LENGTH_LONG).show()
        }
    }
}
